package com.example.a6050110123;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.spinner.R;

public class ShowAll extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all);
        Intent i = getIntent();
        Double x=i.getDoubleExtra("Packet",0.0);
        Integer first=i.getIntExtra("Packet",0);
        Integer second=i.getIntExtra("Packet",0);

        float ratio[] = {1.0f, 0.032808f, 0.907465f, 0.801775f,7.0916f, 107.55003f, 1.326357f, 1.477248f};
        //result = value / ratio[t] * ratio[r];
Double USD,THB,EUR,GBP,CNY,JPY,CAD,AUD;

        USD=x/ratio[first]*1;
        THB =x/ratio[first]*0.032808;
        EUR=x/ratio[first]*0.907465;
        GBP=x/ratio[first]*0.801775;
        CNY=x/ratio[first]*7.0916;
        JPY=x/ratio[first]*107.55003;
        CAD=x/ratio[first]*1.326357;
        AUD=x/ratio[first]*1.477248;

        String[] list = { String.valueOf(USD), String.valueOf(THB)
                , String.valueOf(EUR), String.valueOf(GBP), String.valueOf(CNY)
                , String.valueOf(JPY), String.valueOf(CAD), String.valueOf(AUD)
        };


//        String[] list = { String.valueOf(x/(ratio[first]*1)), String.valueOf(x/(ratio[first]*30.48))
//                , String.valueOf(x/(ratio[first]*0.907465)), String.valueOf(x/(ratio[first]*0.801775), String.valueOf(x/(ratio[first]*7.0916))
//                , String.valueOf(x/(ratio[first]*107.55003)), String.valueOf(x/(ratio[first]*1.326357)),String.valueOf(x/(ratio[first]*1.477248))
//        };
        String[] list2 = { "USD", "THB"
                , "EUR", "GBP", "CNY"
                , "JPY", "CAD", "AUD"
                };

        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), list, list2);
        ListView listView = (ListView)findViewById(R.id.ListAll);
        listView.setAdapter(adapter);

    }
    public void Back(View view){
        finish();
    }

}
