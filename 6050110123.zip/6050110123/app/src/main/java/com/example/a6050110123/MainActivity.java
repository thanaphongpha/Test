package com.example.a6050110123;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.spinner.R;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private Spinner spinner1, spinner2;
    private Button btnSubmit;
    private EditText from;
    private TextView to;
    Double result;
    int index1,index2;
    private CheckBox chk1;
    //private SeekBar Sk1;
    //int progress;
   // SeekBar simpleSeekBar;

    DecimalFormat currency = new DecimalFormat("###,###.##");
    DecimalFormat currencynondecimal = new DecimalFormat("###,###");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        chk1 = (CheckBox) findViewById(R.id.checkBox);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        from = (EditText) findViewById(R.id.InputEditText);

//        int seekBarValue= simpleSeekBar.getProgress();
//
//        simpleSeekBar=(SeekBar)findViewById(R.id.seekBar3);
//        // perform seek bar change listener event used for getting the progress value
//        simpleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
//            int progressChangedValue = 0;
//
//            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
//                progressChangedValue = progress;
//            }
//
//            public void onStartTrackingTouch(SeekBar seekBar) {
//                // TODO Auto-generated method stub
//            }
//
//            public void onStopTrackingTouch(SeekBar seekBar) {
//                Toast.makeText(MainActivity.this, "Seek bar progress is :" + progressChangedValue,
//                        Toast.LENGTH_SHORT).show();
//            }
//        });

        to = (TextView) findViewById(R.id.OutputTextView);
        //Sk1 = (SeekBar) findViewById(R.id.seekBar3);

        spinner1 = (Spinner) findViewById(R.id.spinner1);
        List<String> list1 = new ArrayList<String>();
        list1.add("USD");
        list1.add("THB");
        list1.add("EUR");
        list1.add("GBP");
        list1.add("CNY");
        list1.add("JPY");
        list1.add("CAD");
        list1.add("AUD");
        ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list1);
        dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(dataAdapter1);


        spinner2 = (Spinner) findViewById(R.id.spinner2);
        List<String> list2 = new ArrayList<String>();
        list2.add("USD");
        list2.add("THB");
        list2.add("EUR");
        list2.add("GBP");
        list2.add("CNY");
        list2.add("JPY");
        list2.add("CAD");
        list2.add("AUD");
        ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list2);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter2);




    }


    public void onClick(View v) {
        if(from.getText().toString().equals("")){
            Toast.makeText(this,"กรุณาใส่หมายเลข",Toast.LENGTH_SHORT).show();
        }
        else {
         index1 = spinner1.getSelectedItemPosition();
         index2 = spinner2.getSelectedItemPosition();

        Double value = Double.parseDouble(from.getText().toString());

        /* you have 8 units to convert from and to.
         * that means 8*8 = 64 cases!
         * to minimize work we convert from any selected unit to Centimeter
         * then we convert from Centimeter to the desired unit.
         */

        // ratios from google convertor
        float ratio[] = {1.0f, 30.48f, 0.907465f, 0.801775f,7.0916f, 107.55003f, 1.326357f, 1.477248f};
        result = value / ratio[index1] * ratio[index2];



            if(chk1.isChecked()){


                to.setText(currency.format(result));

                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setTitle("Custom Dialog");
                dialog.setContentView(R.layout.custom_dialog);

                TextView txt_dig;
                TextView txt_digdog;

                txt_dig = (TextView) dialog.findViewById(R.id.dig_textView1);
                txt_digdog = (TextView) dialog.findViewById(R.id.dig_textView2);
                txt_digdog.setText("Result is");
                txt_dig.setText(currency.format(result));


                Button btn_dig_ok = (Button) dialog.findViewById(R.id.dig_button1);
                btn_dig_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
            else {
                to.setText(currencynondecimal.format(result));
                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setTitle("Custom Dialog");
                dialog.setContentView(R.layout.custom_dialog);

                TextView txt_dig;
                TextView txt_digdog;;
                txt_dig = (TextView) dialog.findViewById(R.id.dig_textView1);
                txt_digdog = (TextView) dialog.findViewById(R.id.dig_textView2);
                txt_digdog.setText("Result is");
                txt_dig.setText(currencynondecimal.format(result));


                Button btn_dig_ok = (Button) dialog.findViewById(R.id.dig_button1);
                btn_dig_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        }



    }
    public void Showall(View view){
        if(from.getText().toString().equals("")){
            Toast.makeText(this,"กรุณาใส่หมายเลข",Toast.LENGTH_SHORT).show();
        }
        else {
            Intent i = new Intent(this,ShowAll.class);
            i.putExtra("Packet",Double.parseDouble(from.getText().toString()));
            i.putExtra("Packet2",index1);
            i.putExtra("Packet3",index2);
            startActivity(i);
        }


    }
}