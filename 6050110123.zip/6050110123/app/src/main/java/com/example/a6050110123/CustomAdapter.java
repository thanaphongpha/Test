package com.example.a6050110123;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.spinner.R;

public class CustomAdapter extends BaseAdapter {
    Context mContext;
    String[] strName;
    String[] strLastName;

    //CustomAapter Constructor
    public CustomAdapter(Context context, String[] strName, String[] strLastName) {
        super();
        this.mContext = context;
        this.strName = strName;
        this.strLastName = strLastName;
    }
    public int getCount() {
        return strName.length;
    }
    public Object getItem(int arg0) {
        return null;
    }
    public long getItemId(int arg0) {
        return 0;
    }
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater mInflater = (LayoutInflater)mContext.getSystemService(
                Context.LAYOUT_INFLATER_SERVICE);
        View row = mInflater.inflate(R.layout.listviewrow, parent, false);
        TextView textView = (TextView)row.findViewById(R.id.textView);
        textView.setText(strName[position]);
        TextView textView4 = (TextView)row.findViewById(R.id.textView4);
        textView4.setText(strLastName[position]);
        return row;
    }
}

